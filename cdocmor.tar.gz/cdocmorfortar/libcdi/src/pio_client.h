#ifndef PIO_CLIENT_H
#define PIO_CLIENT_H

void
cdiPioClientSetup(int *pioNamespace_, int *pioNamespace);

#endif

/*
 * Local Variables:
 * c-file-style: "Java"
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * show-trailing-whitespace: t
 * require-trailing-newline: t
 * End:
 */
