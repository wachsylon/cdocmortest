enum foo
{
  bar = 1,
};

void func()
{
  int var;

  for ()
    {
      int x = 2;

      if ()
        {
          var = x;
        }
    }
}

/*
 * Local Variables:
 * c-file-style: "Java"
 * c-basic-offset: 2
 * indent-tabs-mode: nil
 * show-trailing-whitespace: t
 * require-trailing-newline: t
 * End:
 */
