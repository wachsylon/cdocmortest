#! /bin/sh

TEST=test_grib

./${TEST}

result=$?

exit $result
