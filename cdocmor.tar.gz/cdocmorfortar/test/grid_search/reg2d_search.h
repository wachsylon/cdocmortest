#ifndef REG2D_SEARCH_H
#define REG2D_SEARCH_H

#include "grid_search.h"

struct grid_search * reg2d_search_new (struct grid * grid_data);

#endif
