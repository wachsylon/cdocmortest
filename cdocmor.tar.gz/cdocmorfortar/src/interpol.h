
void intgridbil(field_type *field1, field_type *field2);
void intgridcon(field_type *field1, field_type *field2);
void interpolate(field_type *field1, field_type *field2);
